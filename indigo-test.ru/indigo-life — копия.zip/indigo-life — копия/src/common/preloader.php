<div id="preloader" class="preloader ">
    <div id="loader" class="th-preloader">
        <div class="animation-preloader">
            <div class="txt-loading">
                <span preloader-text="A" class="characters">A</span>

                <span preloader-text="7" class="characters">7</span>

                <span preloader-text="R" class="characters">R</span>

                <span preloader-text="E" class="characters">E</span>

                <span preloader-text="N" class="characters">N</span>

                <span preloader-text="T" class="characters">T</span>
            </div>
        </div>
    </div>
</div>