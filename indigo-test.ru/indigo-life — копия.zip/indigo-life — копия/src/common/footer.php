<footer class="footer-wrapper footer-layout3 bg-light">
    <div class="container th-container2">
        <div class="widget-area bg-theme">

        </div>
    </div>
    <div class="copyright-area" data-bg-src="assets/img/bg/footer-bg-3-1.png">
        <div class="container th-container2">
            <div class="copyright-wrap bg-light">
                <div class="footer-container">
                    <div class="row gy-3 align-items-center">
                        <div class="col-lg-6">
                            <p class="copyright-text">
                                Copyright <i class="fal fa-copyright"></i> 2025 <a href="././index.php">A7</a>.</p>
                        </div>
                        <div class="col-lg-6">
                            <div class="th-social justify-content-lg-end justify-content-center">
                                <a href="https://www.facebook.com/"><i class="fab fa-facebook-f"></i></a>
                                <a href="https://www.twitter.com/"><i class="fab fa-twitter"></i></a>
                                <a href="https://www.instagram.com/"><i class="fab fa-youtube"></i></a>
                                <a href="https://www.instagram.com/"><i class="fab fa-instagram"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>